# project_roadster
"Roadster" electric vehicle project for the "Introduction to Scientific Computing" course
