import pytest

pytest.main(["-k", "part3"])
